public class Main {
    public static void main(String[] args) {
        String str ="abcdef";
        System.out.println(str.charAt(0));
    }
}