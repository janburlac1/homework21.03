public class Main {
    public static void main(String[] args) {
    String str = "ab cdefg klmnsd";
    homework (str);
    }

    public static void homework(String str) {
        System.out.println(str.charAt(0));

    }
}