public class Main {
    public static void main(String[] args) {
      // 1 Напишите метод, который принимает три строки и строку-разделитель.
        // Метод возвращает единую строку, состоящую из исходных строк,
        // разделённых строкой-разделителем.
        // Например, на входе "один", "два", "три", "|". На выходе: "один|два|три"
        //2 Напишите метод, который выводит в консоль первый символ переданной в него строки.

        String s = concat("odin" ,"dva" , "tri" , "||");
        System.out.println(s);
        System.out.println();
    }
    private static String concat (String s1 , String s2 , String s3 , String delimiter){
        return s1 + delimiter + s2 + delimiter + s3;

    };
    // //2 Напишите метод, который выводит в консоль первый символ переданной в него строки.
    {
       private static String str  (String Object abcdefg;
       return Object;



    }
}